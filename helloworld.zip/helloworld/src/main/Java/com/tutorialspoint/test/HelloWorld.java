package com.tutorialspoint.test;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "helloWorld", eager = true)
public class HelloWorld {

    public String message = "message from class HelloWorld";

    public HelloWorld() {
        System.out.println("HelloWorld started!");
    }

    public String getMessage() {
        return message;
    }
}